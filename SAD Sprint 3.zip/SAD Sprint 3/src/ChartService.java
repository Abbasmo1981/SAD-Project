package com.shareprice.service;

import com.shareprice.domain.ChartData;
import com.shareprice.domain.ComparisonData;
import com.shareprice.domain.PriceData;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

public class ChartService implements IChartService {

    @Override
    public ChartData generateChart(PriceData data) {
        List<String> labels = data.getDates()
                .stream()
                .map(DateTimeFormatter.ISO_LOCAL_DATE::format)
                .collect(Collectors.toList());

        return new ChartData(
                "Chart for " + data.getSymbol(),
                labels,
                data.getPrices()
        );
    }

    @Override
    public ChartData generateComparisonChart(ComparisonData data) {
        PriceData first = data.getFirst();

        List<String> labels = first.getDates()
                .stream()
                .map(DateTimeFormatter.ISO_LOCAL_DATE::format)
                .collect(Collectors.toList());

        return new ChartData(
                "Comparison: " + first.getSymbol() + " vs " + data.getSecond().getSymbol(),
                labels,
                first.getPrices()
        );
    }
}
