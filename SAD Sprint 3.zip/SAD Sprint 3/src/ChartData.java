package com.shareprice.domain;

import java.util.List;

public class ChartData {
    private final String title;
    private final List<String> labels;
    private final List<Double> values;

    public ChartData(String title, List<String> labels, List<Double> values) {
        this.title = title;
        this.labels = labels;
        this.values = values;
    }

    public String getTitle() { return title; }
    public List<String> getLabels() { return labels; }
    public List<Double> getValues() { return values; }
}
