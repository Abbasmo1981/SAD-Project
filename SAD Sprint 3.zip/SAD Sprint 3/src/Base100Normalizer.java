package com.shareprice.filters;

import com.shareprice.domain.PriceData;

import java.util.List;
import java.util.stream.Collectors;

public class Base100Normalizer {

    public PriceData apply(PriceData data) {
        if (data.getPrices().isEmpty()) return data;

        double base = data.getPrices().get(0);
        if (base == 0.0 || Double.isNaN(base)) return data;

        List<Double> normalized = data.getPrices()
                .stream()
                .map(p -> (p / base) * 100.0)
                .collect(Collectors.toList());

        return new PriceData(
                data.getSymbol(),
                data.getDates(),
                normalized
        );
    }
}
