package com.shareprice.ui;

import com.shareprice.domain.ChartData;
import com.shareprice.service.ISharePriceService;

import java.time.LocalDate;

public class SharePriceController implements ISharePriceUI {

    private final ISharePriceService service;

    public SharePriceController(ISharePriceService service) {
        this.service = service;
    }

    @Override
    public void requestPrice(String symbol, LocalDate from, LocalDate to) {
        try {
            ChartData chart = service.getChartForSymbol(symbol, from, to);
            displayChart(chart);
        } catch (Exception e) {
            displayError(e.getMessage());
        }
    }

    @Override
    public void comparePrices(String s1, String s2, LocalDate from, LocalDate to) {
        try {
            ChartData chart = service.getComparisonChart(s1, s2, from, to);
            displayChart(chart);
        } catch (Exception e) {
            displayError(e.getMessage());
        }
    }

    @Override
    public void displayChart(ChartData chartData) {
        System.out.println("=== " + chartData.getTitle() + " ===");
        for (int i = 0; i < chartData.getLabels().size(); i++) {
            System.out.println(chartData.getLabels().get(i) + " : " + chartData.getValues().get(i));
        }
    }

    @Override
    public void displayError(String message) {
        System.err.println("ERROR: " + message);
    }
}
