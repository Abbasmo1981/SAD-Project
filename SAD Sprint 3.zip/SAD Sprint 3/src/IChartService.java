package com.shareprice.service;

import com.shareprice.domain.ChartData;
import com.shareprice.domain.ComparisonData;
import com.shareprice.domain.PriceData;

public interface IChartService {
    ChartData generateChart(PriceData data);
    ChartData generateComparisonChart(ComparisonData data);
}
