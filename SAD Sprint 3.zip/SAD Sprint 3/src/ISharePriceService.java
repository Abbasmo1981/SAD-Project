package com.shareprice.service;

import com.shareprice.domain.ChartData;
import com.shareprice.domain.PriceData;
import com.shareprice.domain.ComparisonData;

import java.time.LocalDate;

public interface
ISharePriceService {
    PriceData getPriceHistory(String symbol, LocalDate from, LocalDate to);
    ComparisonData compareShares(String s1, String s2, LocalDate from, LocalDate to);
    ChartData getChartForSymbol(String symbol, LocalDate from, LocalDate to);
    ChartData getComparisonChart(String s1, String s2, LocalDate from, LocalDate to);
}
