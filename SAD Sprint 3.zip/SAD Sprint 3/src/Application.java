package com.shareprice;

import com.shareprice.data.IPriceDataProvider;
import com.shareprice.data.IPriceRepository;
import com.shareprice.data.SQLitePriceRepository;
import com.shareprice.data.YahooFinanceProvider;
import com.shareprice.service.ChartService;
import com.shareprice.service.IChartService;
import com.shareprice.service.ISharePriceService;
import com.shareprice.service.SharePriceService;
import com.shareprice.ui.SharePriceController;

import java.time.LocalDate;

public class Application {

    public static void main(String[] args) {

        // --- Data Layer ---
        IPriceDataProvider provider = new YahooFinanceProvider();   // Adapter to external API
        IPriceRepository repository = new SQLitePriceRepository();  // Local storage (offline mode)

        // --- Service Layer ---
        IChartService chartService = new ChartService();
        ISharePriceService sharePriceService =
                new SharePriceService(provider, repository, chartService);

        // --- Presentation Layer (Controller/UI) ---
        SharePriceController controller = new SharePriceController(sharePriceService);

        // --- Demo Execution ---
        LocalDate to = LocalDate.now();
        LocalDate from = to.minusDays(10);

        System.out.println("\n=== SINGLE SHARE PRICE REQUEST ===");
        controller.requestPrice("AAPL", from, to);

        System.out.println("\n=== COMPARISON REQUEST ===");
        controller.comparePrices("AAPL", "MSFT", from, to);
    }
}
