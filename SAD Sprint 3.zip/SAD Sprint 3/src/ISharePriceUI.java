package com.shareprice.ui;

import com.shareprice.domain.ChartData;
import java.time.LocalDate;

public interface ISharePriceUI {
    void requestPrice(String symbol, LocalDate from, LocalDate to);
    void comparePrices(String symbol1, String symbol2, LocalDate from, LocalDate to);
    void displayChart(ChartData chartData);
    void displayError(String message);
}
