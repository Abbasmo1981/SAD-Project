package com.shareprice.service;

import com.shareprice.blackboard.PriceBlackboard;
import com.shareprice.data.IPriceDataProvider;
import com.shareprice.data.IPriceRepository;
import com.shareprice.domain.ChartData;
import com.shareprice.domain.ComparisonData;
import com.shareprice.domain.PriceData;
import com.shareprice.filters.Base100Normalizer;
import com.shareprice.filters.DateRangeFilter;
import com.shareprice.filters.MissingDayFilter;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class SharePriceService implements ISharePriceService {

    private final IPriceDataProvider provider;
    private final IPriceRepository repository;
    private final IChartService chartService;

    private final DateRangeFilter dateRangeFilter = new DateRangeFilter();
    private final MissingDayFilter missingDayFilter = new MissingDayFilter();
    private final Base100Normalizer base100Normalizer = new Base100Normalizer();
    private final PriceBlackboard blackboard = new PriceBlackboard();

    public SharePriceService(IPriceDataProvider provider,
                             IPriceRepository repository,
                             IChartService chartService) {
        this.provider = provider;
        this.repository = repository;
        this.chartService = chartService;
    }

    @Override
    public PriceData getPriceHistory(String symbol, LocalDate from, LocalDate to) {
        validateRange(from, to);

        // 1. Try repository (offline mode)
        PriceData cached = repository.loadPrices(symbol, from, to);
        if (cached != null) {
            PriceData processed = applyPipeline(cached, from, to);
            blackboard.publish(processed);
            return processed;
        }

        // 2. Fetch from external provider
        PriceData fetched = provider.fetchPrices(symbol, from, to);
        repository.savePrices(fetched);

        PriceData processed = applyPipeline(fetched, from, to);
        blackboard.publish(processed);
        return processed;
    }

    @Override
    public ComparisonData compareShares(String s1, String s2, LocalDate from, LocalDate to) {
        PriceData first = getPriceHistory(s1, from, to);
        PriceData second = getPriceHistory(s2, from, to);
        return new ComparisonData(first, second);
    }

    @Override
    public ChartData getChartForSymbol(String symbol, LocalDate from, LocalDate to) {
        PriceData data = getPriceHistory(symbol, from, to);
        return chartService.generateChart(data);
    }

    @Override
    public ChartData getComparisonChart(String s1, String s2, LocalDate from, LocalDate to) {
        ComparisonData comparison = compareShares(s1, s2, from, to);
        return chartService.generateComparisonChart(comparison);
    }

    private PriceData applyPipeline(PriceData data, LocalDate from, LocalDate to) {
        PriceData step1 = dateRangeFilter.apply(data, from, to);
        PriceData step2 = missingDayFilter.apply(step1);
        return base100Normalizer.apply(step2);
    }

    private void validateRange(LocalDate from, LocalDate to) {
        long days = ChronoUnit.DAYS.between(from, to);
        if (days < 0) {
            throw new IllegalArgumentException("From date must be before to date");
        }
        if (days > 730) {
            throw new IllegalArgumentException("Date range must not exceed 2 years");
        }
    }
}
