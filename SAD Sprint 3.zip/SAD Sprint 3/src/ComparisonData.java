package com.shareprice.domain;

public class ComparisonData {
    private final PriceData first;
    private final PriceData second;

    public ComparisonData(PriceData first, PriceData second) {
        this.first = first;
        this.second = second;
    }

    public PriceData getFirst() { return first; }
    public PriceData getSecond() { return second; }
}
