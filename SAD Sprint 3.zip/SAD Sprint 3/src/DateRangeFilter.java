package com.shareprice.filters;

import com.shareprice.domain.PriceData;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.IntStream;

public class DateRangeFilter {

    public PriceData apply(PriceData data, LocalDate from, LocalDate to) {
        List<LocalDate> dates = data.getDates();
        List<Double> prices = data.getPrices();

        if (dates.isEmpty()) return data;

        int start = IntStream.range(0, dates.size())
                .filter(i -> !dates.get(i).isBefore(from))
                .findFirst()
                .orElse(0);

        int end = IntStream.range(0, dates.size())
                .filter(i -> !dates.get(i).isAfter(to))
                .reduce((a, b) -> b)
                .orElse(dates.size() - 1);

        return new PriceData(
                data.getSymbol(),
                dates.subList(start, end + 1),
                prices.subList(start, end + 1)
        );
    }
}
