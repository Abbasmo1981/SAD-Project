package com.shareprice.data;

import com.shareprice.domain.PriceData;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

public class SQLitePriceRepository implements IPriceRepository {

    private final Map<String, PriceData> cache = new HashMap<>();

    @Override
    public PriceData loadPrices(String symbol, LocalDate from, LocalDate to) {
        return cache.get(symbol);
    }

    @Override
    public void savePrices(PriceData data) {
        cache.put(data.getSymbol(), data);
    }
}
