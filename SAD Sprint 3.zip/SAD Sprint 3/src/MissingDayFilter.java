package com.shareprice.filters;

import com.shareprice.domain.PriceData;

public class MissingDayFilter {

    public PriceData apply(PriceData data) {
        // For coursework: no interpolation, just return as-is
        return data;
    }
}
