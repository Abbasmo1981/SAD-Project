package com.shareprice.domain;

import java.time.LocalDate;
import java.util.List;

public class PriceData {
    private final String symbol;
    private final List<LocalDate> dates;
    private final List<Double> prices;

    public PriceData(String symbol, List<LocalDate> dates, List<Double> prices) {
        this.symbol = symbol;
        this.dates = dates;
        this.prices = prices;
    }

    public String getSymbol() { return symbol; }
    public List<LocalDate> getDates() { return dates; }
    public List<Double> getPrices() { return prices; }
}
