package com.shareprice.data;

import com.shareprice.domain.PriceData;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

public class YahooFinanceProvider implements IPriceDataProvider {

    @Override
    public PriceData fetchPrices(String symbol, LocalDate from, LocalDate to) {
        try {
            String urlStr = "https://query1.finance.yahoo.com/v8/finance/chart/"
                    + symbol + "?interval=1d&range=2y";

            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(conn.getInputStream())
            );

            StringBuilder response = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                response.append(line);
            }

            reader.close();

            JSONObject json = new JSONObject(response.toString());
            JSONObject result = json.getJSONObject("chart")
                    .getJSONArray("result")
                    .getJSONObject(0);

            JSONArray timestamps = result.getJSONArray("timestamp");
            JSONArray closes = result.getJSONObject("indicators")
                    .getJSONArray("quote")
                    .getJSONObject(0)
                    .getJSONArray("close");

            List<LocalDate> dates = new ArrayList<>();
            List<Double> prices = new ArrayList<>();

            for (int i = 0; i < timestamps.length(); i++) {
                long ts = timestamps.getLong(i);
                LocalDate date = Instant.ofEpochSecond(ts)
                        .atZone(ZoneId.systemDefault())
                        .toLocalDate();

                if (!date.isBefore(from) && !date.isAfter(to)) {
                    dates.add(date);

                    if (closes.isNull(i)) {
                        prices.add(Double.NaN);
                    } else {
                        prices.add(closes.getDouble(i));
                    }
                }
            }

            return new PriceData(symbol, dates, prices);

        } catch (Exception e) {
            throw new RuntimeException("Failed to fetch Yahoo Finance data: " + e.getMessage(), e);
        }
    }
}
