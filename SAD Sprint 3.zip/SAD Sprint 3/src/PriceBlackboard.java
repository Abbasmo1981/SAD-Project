package com.shareprice.blackboard;

import com.shareprice.domain.PriceData;

import java.util.ArrayList;
import java.util.List;

public class PriceBlackboard {

    private PriceData cachedData;
    private final List<BlackboardListener> listeners = new ArrayList<>();

    public void publish(PriceData data) {
        this.cachedData = data;
        for (BlackboardListener listener : listeners) {
            listener.onUpdate(data);
        }
    }

    public PriceData get() {
        return cachedData;
    }

    public void subscribe(BlackboardListener listener) {
        listeners.add(listener);
    }
}
