package com.shareprice.blackboard;

import com.shareprice.domain.PriceData;

public interface BlackboardListener {
    void onUpdate(PriceData data);
}
