package com.shareprice.data;

import com.shareprice.domain.PriceData;
import java.time.LocalDate;

public interface IPriceRepository {
    PriceData loadPrices(String symbol, LocalDate from, LocalDate to);
    void savePrices(PriceData data);
}
