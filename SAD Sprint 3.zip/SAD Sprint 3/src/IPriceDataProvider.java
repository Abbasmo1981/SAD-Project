package com.shareprice.data;

import com.shareprice.domain.PriceData;
import java.time.LocalDate;

public interface IPriceDataProvider {
    PriceData fetchPrices(String symbol, LocalDate from, LocalDate to);
}
