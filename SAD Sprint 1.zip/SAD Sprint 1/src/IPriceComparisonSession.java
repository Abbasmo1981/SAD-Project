package com.example.app;

public interface IPriceComparisonSession {
    void runComparison(String symbol1, String symbol2);
}
