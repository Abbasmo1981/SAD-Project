package com.stockapp;

import com.stockapp.controller.StockController;

public class Main {
    public static void main(String[] args) {
        StockController controller = new StockController();
        controller.searchSharePrice("AAPL", "2024-01-01", "2024-06-01");
        controller.compareCompanies("AAPL", "MSFT");
    }
}
