package com.example.app;

// Added this import exactly as you requested
import infrastructure.YahooApi;

import interfaces.IPriceRepository;
import interfaces.IChartService;
import model.PriceData;

public class PriceComparisonSession {

    private YahooApi api;
    private IPriceRepository repo;
    private IChartService chart;

    public PriceComparisonSession(YahooApi api,
                                  IPriceRepository repo,
                                  IChartService chart) {

        this.api = api;
        this.repo = repo;
        this.chart = chart;
    }

    public void runComparison(String symbol1, String symbol2) {

        System.out.println("Starting comparison...");

        // Fetch prices
        PriceData p1 = api.fetchPrices(symbol1, null, null);
        PriceData p2 = api.fetchPrices(symbol2, null, null);

        // Save to repository
        repo.savePrices(p1);
        repo.savePrices(p2);

        // Generate charts
        chart.generateChart(p1);
        chart.generateChart(p2);

        System.out.println("Comparison complete.");
    }
}
