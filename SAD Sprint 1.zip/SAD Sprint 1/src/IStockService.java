package com.stockapp.service;

public interface IStockService {
    void handleSearch(String symbol, String start, String end);
    void compareCompanies(String symbol1, String symbol2);
    void enableOfflineMode();
}
