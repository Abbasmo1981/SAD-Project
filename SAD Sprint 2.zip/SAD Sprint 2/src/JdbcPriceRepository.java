public class JdbcPriceRepository implements PriceRepository {

    private final DataSource dataSource;

    public JdbcPriceRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public Optional<PriceSeries> find(String ticker, LocalDate from, LocalDate to) {
        String sql = """
            SELECT trade_date, close_price
            FROM prices
            WHERE ticker = ? AND trade_date BETWEEN ? AND ?
            ORDER BY trade_date
        """;

        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, ticker);
            ps.setObject(2, from);
            ps.setObject(3, to);

            ResultSet rs = ps.executeQuery();
            List<PricePoint> points = new ArrayList<>();

            while (rs.next()) {
                points.add(new PricePoint(
                        rs.getObject("trade_date", LocalDate.class),
                        rs.getDouble("close_price")
                ));
            }

            if (points.isEmpty()) return Optional.empty();
            return Optional.of(new PriceSeries(ticker, points));

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void save(PriceSeries series) {
        String sql = "INSERT OR REPLACE INTO prices(ticker, trade_date, close_price) VALUES(?,?,?)";

        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            for (PricePoint p : series.getPoints()) {
                ps.setString(1, series.getTicker());
                ps.setObject(2, p.getDate());
                ps.setDouble(3, p.getClose());
                ps.addBatch();
            }

            ps.executeBatch();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
