public class PriceAnalysis {

    public PriceSeries process(PriceSeries series) {
        List<PricePoint> sorted = series.getPoints().stream()
                .sorted(Comparator.comparing(PricePoint::getDate))
                .toList();

        List<PricePoint> normalized = normalizeBase100(sorted);

        return new PriceSeries(series.getTicker(), normalized);
    }

    private List<PricePoint> normalizeBase100(List<PricePoint> points) {
        double base = points.get(0).getClose();
        return points.stream()
                .map(p -> new PricePoint(p.getDate(), (p.getClose() / base) * 100))
                .toList();
    }
}
