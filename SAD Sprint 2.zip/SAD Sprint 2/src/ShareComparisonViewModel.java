public class ShareComparisonViewModel {

    public static ShareComparisonViewModel from(ComparisonResult result) {
        return new ShareComparisonViewModel(
                result.getSeriesA(),
                result.getSeriesB()
        );
    }

    // fields + getters omitted for brevity
}
