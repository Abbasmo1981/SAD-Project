import java.time.LocalDate;

public interface IUserMgt {
    SearchRequest createSearchRequest(LocalDate startDate, LocalDate endDate);
    Chart viewChart(String userId);
}
