public interface ICompanyMgt {
    Company getCompany(String symbol);
    java.util.List<Price> getCompanyPrices(String symbol);
    ComparisonResult getCompanyComparison(String symbol1, String symbol2);
}
