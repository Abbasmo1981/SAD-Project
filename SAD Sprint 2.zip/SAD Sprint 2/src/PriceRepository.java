public interface PriceRepository {
    Optional<PriceSeries> find(String ticker, LocalDate from, LocalDate to);
    void save(PriceSeries series);
}
