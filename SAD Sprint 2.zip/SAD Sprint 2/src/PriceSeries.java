public class PriceSeries {
    private final String ticker;
    private final List<PricePoint> points;

    public PriceSeries(String ticker, List<PricePoint> points) {
        this.ticker = ticker;
        this.points = points;
    }

    public String getTicker() { return ticker; }
    public List<PricePoint> getPoints() { return points; }
}
