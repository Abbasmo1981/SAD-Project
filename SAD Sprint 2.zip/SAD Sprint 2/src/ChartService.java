import java.util.List;

public class ChartService {

    public Chart generateChart(List<Price> prices) {
        System.out.println("Generating chart...");
        return new Chart(prices, "LineChart");
    }
}
