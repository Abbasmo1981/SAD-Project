public interface PriceService {
    PriceSeries getSeries(String ticker, LocalDate from, LocalDate to);
    ComparisonResult compare(String a, String b, LocalDate from, LocalDate to);
}
