import java.time.LocalDate;

public class Main {

    public static void main(String[] args) {

        // -----------------------------
        // Infrastructure Layer
        // -----------------------------
        DataSource dataSource = DatabaseConfig.createDataSource();
        PriceRepository repository = new JdbcPriceRepository(dataSource);

        YahooFinanceClient client = new YahooFinanceClient();
        DataSourceService dataSourceService = new YahooFinanceProvider(client);

        // -----------------------------
        // Domain Layer
        // -----------------------------
        PriceAnalysis analysis = new PriceAnalysis();

        // -----------------------------
        // Application Layer
        // -----------------------------
        PriceService priceService =
                new PriceServiceImpl(repository, dataSourceService, analysis);

        // -----------------------------
        // Presentation Layer
        // -----------------------------
        ShareComparisonController controller =
                new ShareComparisonController(priceService);

        // -----------------------------
        // Example Run
        // -----------------------------
        LocalDate from = LocalDate.now().minusDays(5);
        LocalDate to = LocalDate.now();

        System.out.println("Comparing AAPL vs MSFT...");
        ShareComparisonViewModel vm =
                controller.compare("AAPL", "MSFT", from, to);

        System.out.println("Comparison complete.");
        System.out.println("AAPL points: " + vm.getSeriesA().getPoints().size());
        System.out.println("MSFT points: " + vm.getSeriesB().getPoints().size());
    }
}
