public class ComparisonResult {
    private final PriceSeries seriesA;
    private final PriceSeries seriesB;

    public ComparisonResult(PriceSeries a, PriceSeries b) {
        this.seriesA = a;
        this.seriesB = b;
    }

    public PriceSeries getSeriesA() { return seriesA; }
    public PriceSeries getSeriesB() { return seriesB; }
}
