import java.util.List;

public class Chart {
    private List<Price> prices;
    private String chartType;

    public Chart(List<Price> prices, String chartType) {
        this.prices = prices;
        this.chartType = chartType;
    }

    public List<Price> getPrices() { return prices; }
}
