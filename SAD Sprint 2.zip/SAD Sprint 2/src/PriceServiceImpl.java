public class PriceServiceImpl implements PriceService {

    private final PriceRepository repository;
    private final DataSourceService dataSource;
    private final PriceAnalysis analysis;

    public PriceServiceImpl(PriceRepository repository,
                            DataSourceService dataSource,
                            PriceAnalysis analysis) {
        this.repository = repository;
        this.dataSource = dataSource;
        this.analysis = analysis;
    }

    @Override
    public PriceSeries getSeries(String ticker, LocalDate from, LocalDate to) {
        return repository.find(ticker, from, to)
                .orElseGet(() -> {
                    List<PricePoint> fetched = dataSource.fetch(ticker, from, to);
                    PriceSeries series = new PriceSeries(ticker, fetched);
                    repository.save(series);
                    return series;
                });
    }

    @Override
    public ComparisonResult compare(String a, String b, LocalDate from, LocalDate to) {
        PriceSeries s1 = analysis.process(getSeries(a, from, to));
        PriceSeries s2 = analysis.process(getSeries(b, from, to));
        return new ComparisonResult(s1, s2);
    }
}
