import java.time.LocalDate;

public class Price {
    private LocalDate date;
    private double value;

    public Price(LocalDate date, double value) {
        this.date = date;
        this.value = value;
    }

    public LocalDate getDate() { return date; }
    public double getValue() { return value; }
}
