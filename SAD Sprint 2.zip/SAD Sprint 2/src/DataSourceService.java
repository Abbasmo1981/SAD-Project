public interface DataSourceService {
    List<PricePoint> fetch(String ticker, LocalDate from, LocalDate to);
}
