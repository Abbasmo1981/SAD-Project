public class ShareComparisonController {

    private final PriceService priceService;

    public ShareComparisonController(PriceService priceService) {
        this.priceService = priceService;
    }

    public ShareComparisonViewModel compare(String a, String b, LocalDate from, LocalDate to) {
        ComparisonResult result = priceService.compare(a, b, from, to);
        return ShareComparisonViewModel.from(result);
    }
}
