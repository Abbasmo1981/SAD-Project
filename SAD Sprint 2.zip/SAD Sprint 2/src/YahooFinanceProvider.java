public class YahooFinanceProvider implements DataSourceService {

    private final YahooFinanceClient client;

    public YahooFinanceProvider(YahooFinanceClient client) {
        this.client = client;
    }

    @Override
    public List<PricePoint> fetch(String ticker, LocalDate from, LocalDate to) {
        List<YahooPriceDTO> raw = client.getHistoricalPrices(ticker, from, to);

        return raw.stream()
                .map(dto -> new PricePoint(dto.date(), dto.close()))
                .toList();
    }
}
