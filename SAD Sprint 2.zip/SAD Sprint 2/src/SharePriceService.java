import java.time.LocalDate;
import java.util.List;

public class SharePriceService {

    private PriceRepository repository;
    private YahooFinanceProvider externalProvider;
    private ChartService chartService;

    public SharePriceService(PriceRepository repo, YahooFinanceProvider provider, ChartService chartService) {
        this.repository = repo;
        this.externalProvider = provider;
        this.chartService = chartService;
    }

    public Chart getChartForSymbol(String symbol, LocalDate start, LocalDate end) {

        List<Price> prices = repository.loadPrices(symbol, start, end);

        if (prices == null || prices.isEmpty()) {
            prices = externalProvider.fetchPrices(symbol, start, end);
            repository.savePrices(prices);
        }

        return chartService.generateChart(prices);
    }
}
