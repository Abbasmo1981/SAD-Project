package com.example.app;

public class BrowserView implements IBrowserView {
    public void showMessage(String msg) {
        System.out.println("[Browser] " + msg);
    }
}
