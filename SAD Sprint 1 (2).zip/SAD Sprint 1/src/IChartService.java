package com.example.app;

public interface IChartService {
    void drawChart(IPriceData data);
}
