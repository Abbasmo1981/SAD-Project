package com.example.app;

public class UserInfo implements IUserInfo {
    private final String name;

    public UserInfo(String name) {
        this.name = name;
    }

    public String getName() { return name; }
}
