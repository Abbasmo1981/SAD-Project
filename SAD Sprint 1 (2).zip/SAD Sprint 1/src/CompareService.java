package com.example.app;

public class CompareService {

    public void compare(IPriceData a, IPriceData b) {
        System.out.println("[Compare] " + a.getSymbol() + " vs " + b.getSymbol());
        System.out.println("Prices: " + a.getPrice() + " vs " + b.getPrice());
    }
}
