package com.example.app;

import java.util.HashMap;

public class PriceRepository implements IPriceRepository {

    private final HashMap<String, IPriceData> storage = new HashMap<>();

    public void save(IPriceData data) {
        storage.put(data.getSymbol(), data);
    }

    public IPriceData load(String symbol) {
        return storage.get(symbol);
    }
}
