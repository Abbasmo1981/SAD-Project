package com.example.app;

public interface IPriceRepository {
    void save(IPriceData data);
    IPriceData load(String symbol);
}
