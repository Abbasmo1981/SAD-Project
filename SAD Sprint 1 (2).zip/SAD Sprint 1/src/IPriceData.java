package com.example.app;

public interface IPriceData {
    String getSymbol();
    double getPrice();
}
