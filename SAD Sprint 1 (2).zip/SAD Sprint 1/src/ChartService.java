package com.example.app;

public class ChartService implements IChartService {

    public void drawChart(IPriceData data) {
        System.out.println("[Chart] Drawing chart for " + data.getSymbol() +
                " price: " + data.getPrice());
    }
}
