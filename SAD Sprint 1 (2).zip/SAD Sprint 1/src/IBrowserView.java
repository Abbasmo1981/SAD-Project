package com.example.app;

public interface IBrowserView {
    void showMessage(String msg);
}
