package com.example.app;

public class YahooApi {

    public IPriceData getPrice(String symbol) {
        double randomPrice = Math.random() * 100;
        return new PriceData(symbol, randomPrice);
    }
}
