package com.example.app;

public class PriceData implements IPriceData {
    private final String symbol;
    private final double price;

    public PriceData(String symbol, double price) {
        this.symbol = symbol;
        this.price = price;
    }

    public String getSymbol() { return symbol; }
    public double getPrice() { return price; }
}
