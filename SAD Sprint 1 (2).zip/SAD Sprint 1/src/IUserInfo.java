package com.example.app;

public interface IUserInfo {
    String getName();
}
