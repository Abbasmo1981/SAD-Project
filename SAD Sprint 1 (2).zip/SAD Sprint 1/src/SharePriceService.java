package com.example.app;

public class SharePriceService {

    public void share(IPriceData data) {
        System.out.println("[Share] Sharing price: " + data.getSymbol() +
                " = " + data.getPrice());
    }
}
