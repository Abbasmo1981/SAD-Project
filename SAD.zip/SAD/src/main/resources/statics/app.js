function loadStock() {
  const symbol = document.getElementById("symbol").value;

  fetch(`/api/stock/${symbol}`)
    .then(res => res.json())
    .then(data => {
      console.log(data); // IMPORTANT DEBUG

      // example chart data (adjust to your API)
      const prices = data.prices;

      const ctx = document.getElementById("chart");

      new Chart(ctx, {
        type: 'line',
        data: {
          labels: prices.map((_, i) => i),
          datasets: [{ [
                         {"date":"2026-05-08","close":123.45},
                         {"date":"2026-05-07","close":120.10}
                       ]
            data: prices
          }]
        }
      });
    })
    .catch(err => console.log("ERROR:", err));
}