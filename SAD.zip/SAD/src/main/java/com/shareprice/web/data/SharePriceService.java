package com.shareprice.web.data;

import com.shareprice.web.data.IPriceDataProvider;
import com.shareprice.web.data.IPriceRepository;
import com.shareprice.web.domain.PriceData;
import com.shareprice.web.service.ISharePriceService;

import java.util.List;

public class SharePriceService implements ISharePriceService {

    private final IPriceDataProvider provider;
    private final IPriceRepository repo;

    public SharePriceService(IPriceDataProvider provider,
                             IPriceRepository repo) {
        this.provider = provider;
        this.repo = repo;
    }

    @Override
    public List<PriceData> getPrices(String symbol,
                                     String start,
                                     String end) {

        List<PriceData> cached = repo.loadPrices(symbol);

        if (cached != null && !cached.isEmpty()) {
            return cached;
        }

        List<PriceData> fresh = provider.fetchPrices(symbol, start, end);

        if (fresh != null && !fresh.isEmpty()) {
            repo.savePrices(symbol, fresh);
        }

        return fresh;
    }
}
