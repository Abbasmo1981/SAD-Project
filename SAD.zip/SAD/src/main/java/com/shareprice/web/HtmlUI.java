package com.shareprice.web;

import com.sun.net.httpserver.HttpHandler;

import java.io.InputStream;

public class HtmlUI {

    public static HttpHandler page(String fileName) {
        return exchange -> {
            try {
                InputStream is =
                        HtmlUI.class.getResourceAsStream(
                                "/web/" + fileName
                        );

                if (is == null) {
                    String msg = "File not found: " + fileName;
                    exchange.sendResponseHeaders(404, msg.length());
                    exchange.getResponseBody().write(msg.getBytes());
                    exchange.close();
                    return;
                }

                byte[] bytes = is.readAllBytes();

                exchange.getResponseHeaders()
                        .add("Content-Type", "text/html; charset=utf-8");

                exchange.sendResponseHeaders(200, bytes.length);
                exchange.getResponseBody().write(bytes);
                exchange.close();

            } catch (Exception e) {
                e.printStackTrace();
            }
        };
    }
}
