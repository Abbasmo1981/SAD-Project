package com.shareprice.web.auth;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class SessionStore {

    private Map<String, String> sessions = new HashMap<>();
    // token -> username

    public String createSession(String username) {
        String token = UUID.randomUUID().toString();
        sessions.put(token, username);
        return token;
    }

    public String getUser(String token) {
        return sessions.get(token);
    }

    public boolean isValid(String token) {
        return sessions.containsKey(token);
    }

    public void remove(String token) {
        sessions.remove(token);
    }
}