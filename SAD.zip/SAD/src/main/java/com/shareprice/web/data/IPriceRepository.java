package com.shareprice.web.data;

import com.shareprice.web.domain.PriceData;
import java.util.List;

public interface IPriceRepository {

    void savePrices(String symbol, List<PriceData> prices);

    List<PriceData> loadPrices(String symbol);
}