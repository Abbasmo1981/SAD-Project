package com.shareprice.web.domain;

public class User {
}
