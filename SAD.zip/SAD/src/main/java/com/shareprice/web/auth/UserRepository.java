package com.shareprice.web.auth;

import java.util.HashMap;
import java.util.Map;

public class UserRepository {

    private final Map<String, User> users = new HashMap<>();

    // Keep the constructor signature used in Main, but ignore the path for now
    public UserRepository(String path) {
        // In-memory only; could be extended to load/save from JSON file at 'path'
    }

    public boolean exists(String username) {
        return users.containsKey(username);
    }

    public void save(User user) {
        users.put(user.getUsername(), user);
    }

    public User find(String username) {
        return users.get(username);
    }
}
