package com.shareprice.web.service;

import com.shareprice.web.domain.PriceData;
import java.util.List;

public interface IChartService {
    byte[] generateChart(List<PriceData> prices);
}