package com.shareprice.web.data;

import com.shareprice.web.domain.PriceData;
import org.json.JSONObject;

import java.util.List;

public interface IPriceDataProvider {

    JSONObject fetchPrices(String symbol);

    List<PriceData> fetchPrices(String symbol, String start, String end);
}