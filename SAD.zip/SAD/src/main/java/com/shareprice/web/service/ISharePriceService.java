package com.shareprice.web.service;

import com.shareprice.web.domain.PriceData;
import java.util.List;

public interface ISharePriceService {

    List<PriceData> getPrices(String symbol,
                              String start,
                              String end);
}