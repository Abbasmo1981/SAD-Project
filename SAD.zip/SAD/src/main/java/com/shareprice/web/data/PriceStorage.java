package com.shareprice.web.data;

import com.shareprice.web.domain.PriceData;
import java.util.*;

public class PriceStorage implements IPriceRepository {

    private final Map<String, List<PriceData>> db =
            new HashMap<>();

    @Override
    public void savePrices(String symbol,
                           List<PriceData> prices) {
        db.put(symbol, prices);
    }

    @Override
    public List<PriceData> loadPrices(String symbol) {
        return db.getOrDefault(symbol, new ArrayList<>());
    }
}