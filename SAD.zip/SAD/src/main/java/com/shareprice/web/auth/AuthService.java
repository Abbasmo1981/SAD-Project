package com.shareprice.web.auth;

import com.shareprice.util.PasswordUtil;

public class AuthService {

    private UserRepository repo;
    private SessionStore sessionStore;

    public AuthService(UserRepository repo, SessionStore sessionStore) {
        this.repo = repo;
        this.sessionStore = sessionStore;
    }

    public boolean register(String username, String password) {

        if (repo.exists(username)) return false;

        String hash = PasswordUtil.hash(password);

        repo.save(new User(username, hash));
        return true;
    }

    public String login(String username, String password) {

        User user = repo.find(username);
        if (user == null) return null;

        String hash = PasswordUtil.hash(password);

        if (!user.getPasswordHash().equals(hash)) {
            return null;
        }

        return sessionStore.createSession(username);
    }

    public boolean validate(String token) {
        return sessionStore.isValid(token);
    }

    public String getUser(String token) {
        return sessionStore.getUser(token);
    }

    public void logout(String token) {
        sessionStore.remove(token);
    }
}