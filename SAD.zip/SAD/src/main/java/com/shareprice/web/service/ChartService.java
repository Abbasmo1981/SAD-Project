package com.shareprice.web.service;

import com.shareprice.web.domain.PriceData;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.util.List;

public class ChartService implements IChartService {

    @Override
    public byte[] generateChart(List<PriceData> prices) {

        try {
            int width = 800;
            int height = 400;

            BufferedImage image =
                    new BufferedImage(
                            width,
                            height,
                            BufferedImage.TYPE_INT_ARGB
                    );

            Graphics2D g = image.createGraphics();

            g.setColor(Color.WHITE);
            g.fillRect(0, 0, width, height);

            g.setColor(Color.BLACK);
            g.drawRect(50, 50, 700, 250);

            // Simple line chart for close prices
            if (prices != null && prices.size() > 1) {
                double min = prices.stream().mapToDouble(PriceData::getClose).min().orElse(0);
                double max = prices.stream().mapToDouble(PriceData::getClose).max().orElse(1);

                int n = prices.size();
                int chartX = 50;
                int chartY = 50;
                int chartW = 700;
                int chartH = 250;

                g.setColor(Color.BLUE);

                for (int i = 0; i < n - 1; i++) {
                    double v1 = prices.get(i).getClose();
                    double v2 = prices.get(i + 1).getClose();

                    int x1 = chartX + (int) ((i / (double) (n - 1)) * chartW);
                    int x2 = chartX + (int) (((i + 1) / (double) (n - 1)) * chartW);

                    int y1 = chartY + chartH - (int) ((v1 - min) / (max - min + 0.0001) * chartH);
                    int y2 = chartY + chartH - (int) ((v2 - min) / (max - min + 0.0001) * chartH);

                    g.drawLine(x1, y1, x2, y2);
                }
            }

            g.dispose();

            ByteArrayOutputStream output = new ByteArrayOutputStream();
            ImageIO.write(image, "png", output);

            return output.toByteArray();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }
}
