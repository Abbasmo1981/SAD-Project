package com.shareprice.web.data;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.shareprice.web.domain.PriceData;
import org.json.JSONObject;

public class AlphaVantageProvider implements IPriceDataProvider {

    private static final String API_KEY = "6LNJZ1XFRWCTEOF1";

    @Override
    public JSONObject fetchPrices(String symbol) {
        try {
            String url =
                    "https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol="
                            + symbol
                            + "&apikey="
                            + API_KEY;

            HttpClient client = HttpClient.newHttpClient();

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .GET()
                    .build();

            HttpResponse<String> response =
                    client.send(request, HttpResponse.BodyHandlers.ofString());

            JSONObject json = new JSONObject(response.body());

            if (json.has("Error Message") || json.has("Note")) {
                System.out.println("AlphaVantage response issue: " + json);
                return null;
            }

            return json;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<PriceData> fetchPrices(String symbol, String start, String end) {
        try {
            JSONObject json = fetchPrices(symbol);
            if (json == null) return List.of();

            if (!json.has("Time Series (Daily)")) return List.of();

            JSONObject series = json.getJSONObject("Time Series (Daily)");

            LocalDate startDate = LocalDate.parse(start);
            LocalDate endDate = LocalDate.parse(end);

            List<PriceData> result = new ArrayList<>();

            for (String dateStr : series.keySet()) {
                LocalDate date = LocalDate.parse(dateStr);
                if (date.isBefore(startDate) || date.isAfter(endDate)) {
                    continue;
                }

                JSONObject day = series.getJSONObject(dateStr);

                double open = day.getDouble("1. open");
                double high = day.getDouble("2. high");
                double low = day.getDouble("3. low");
                double close = day.getDouble("4. close");

                result.add(new PriceData(date, open, high, low, close));
            }

            // Optional: sort by date ascending
            result.sort((a, b) -> a.getDate().compareTo(b.getDate()));

            return result;

        } catch (Exception e) {
            e.printStackTrace();
            return List.of();
        }
    }
}
