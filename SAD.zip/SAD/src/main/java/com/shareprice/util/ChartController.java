package com.shareprice.util;

import com.shareprice.web.auth.AuthService;
import com.shareprice.web.service.IChartService;
import com.shareprice.web.service.ISharePriceService;
import com.sun.net.httpserver.HttpHandler;

public class ChartController {

    public ChartController(ISharePriceService priceService,
                           IChartService chartService,
                           AuthService authService) {
    }

    public HttpHandler chart() {
        return exchange -> {
            String msg = "chart endpoint working";
            exchange.sendResponseHeaders(200, msg.length());
            exchange.getResponseBody().write(msg.getBytes());
            exchange.close();
        };
    }
}