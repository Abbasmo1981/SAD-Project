package com.shareprice;

import com.shareprice.controller.AuthController;
import com.shareprice.controller.ChartController;
import com.shareprice.controller.PriceController;

import com.shareprice.web.HtmlUI;
import com.shareprice.web.auth.AuthService;
import com.shareprice.web.auth.SessionStore;
import com.shareprice.web.auth.UserRepository;

import com.shareprice.web.data.AlphaVantageProvider;
import com.shareprice.web.data.IPriceDataProvider;
import com.shareprice.web.data.IPriceRepository;
import com.shareprice.web.data.PriceStorage;

import com.shareprice.web.service.ChartService;
import com.shareprice.web.service.IChartService;
import com.shareprice.web.service.ISharePriceService;
import com.shareprice.web.service.SharePriceService;

import com.sun.net.httpserver.HttpServer;

import java.io.InputStream;
import java.net.InetSocketAddress;

public class Main {

    public static void main(String[] args) throws Exception {

        SessionStore sessionStore = new SessionStore();
        UserRepository userRepo = new UserRepository("users.json");

        AuthService authService =
                new AuthService(userRepo, sessionStore);

        IPriceDataProvider provider =
                new AlphaVantageProvider();

        IPriceRepository repo =
                new PriceStorage();

        ISharePriceService priceService =
                new SharePriceService(provider, repo);

        IChartService chartService =
                new ChartService();

        AuthController authController =
                new AuthController(authService);

        PriceController priceController =
                new PriceController(
                        priceService,
                        authService
                );

        ChartController chartController =
                new ChartController(
                        priceService,
                        chartService,
                        authService
                );

        HttpServer server =
                HttpServer.create(
                        new InetSocketAddress(8080),
                        0
                );

        // Root → login page
        server.createContext("/", HtmlUI.page("login.html"));
        server.createContext("/login", HtmlUI.page("login.html"));
        server.createContext("/register", HtmlUI.page("register.html"));
        server.createContext("/dashboard", HtmlUI.page("dashboard.html"));

        // Static resources
        server.createContext("/style.css", exchange -> {
            try (InputStream is = Main.class.getResourceAsStream("/web/style.css")) {
                if (is == null) {
                    String msg = "File not found: style.css";
                    exchange.sendResponseHeaders(404, msg.length());
                    exchange.getResponseBody().write(msg.getBytes());
                    exchange.close();
                    return;
                }
                byte[] bytes = is.readAllBytes();
                exchange.getResponseHeaders().set("Content-Type", "text/css; charset=utf-8");
                exchange.sendResponseHeaders(200, bytes.length);
                exchange.getResponseBody().write(bytes);
                exchange.close();
            }
        });

        // API endpoints
        server.createContext("/api/register", authController.register());
        server.createContext("/api/login", authController.login());
        server.createContext("/api/prices", priceController.prices());
        server.createContext("/api/chart", chartController.chart());

        server.setExecutor(null);
        server.start();

        System.out.println("Server running at http://localhost:8080");
    }
}
