package com.shareprice.controller;

import com.shareprice.web.auth.AuthService;
import com.shareprice.web.domain.PriceData;
import com.shareprice.web.service.IChartService;
import com.shareprice.web.service.ISharePriceService;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.OutputStream;
import java.time.LocalDate;
import java.util.List;

public class ChartController {

    private final ISharePriceService priceService;
    private final IChartService chartService;
    private final AuthService authService;

    public ChartController(ISharePriceService priceService,
                           IChartService chartService,
                           AuthService authService) {
        this.priceService = priceService;
        this.chartService = chartService;
        this.authService = authService;
    }

    public HttpHandler chart() {
        return exchange -> {
            try {
                // Token validation
                String authHeader = exchange.getRequestHeaders().getFirst("Authorization");
                if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                    String error = "Missing or invalid Authorization header";
                    exchange.sendResponseHeaders(401, error.length());
                    exchange.getResponseBody().write(error.getBytes());
                    exchange.close();
                    return;
                }

                String token = authHeader.substring("Bearer ".length()).trim();
                if (!authService.validate(token)) {
                    String error = "Invalid or expired token";
                    exchange.sendResponseHeaders(401, error.length());
                    exchange.getResponseBody().write(error.getBytes());
                    exchange.close();
                    return;
                }

                // Get stock symbol from URL
                String query = exchange.getRequestURI().getQuery();
                if (query == null || !query.contains("symbol=")) {
                    String error = "Missing stock symbol";
                    exchange.sendResponseHeaders(400, error.length());
                    exchange.getResponseBody().write(error.getBytes());
                    exchange.close();
                    return;
                }

                String symbol = query.split("symbol=")[1].split("&")[0];

                String endDate = LocalDate.now().toString();
                String startDate = LocalDate.now().minusDays(30).toString();

                List<PriceData> prices = priceService.getPrices(symbol, startDate, endDate);

                if (prices == null || prices.isEmpty()) {
                    String error = "No stock data found";
                    exchange.sendResponseHeaders(404, error.length());
                    exchange.getResponseBody().write(error.getBytes());
                    exchange.close();
                    return;
                }

                byte[] chartBytes = chartService.generateChart(prices);

                exchange.getResponseHeaders().add("Content-Type", "image/png");
                exchange.sendResponseHeaders(200, chartBytes.length);

                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(chartBytes);
                }

            } catch (Exception e) {
                e.printStackTrace();
                String error = "Chart generation failed";
                exchange.sendResponseHeaders(500, error.length());
                exchange.getResponseBody().write(error.getBytes());
                exchange.close();
            }
        };
    }
}
