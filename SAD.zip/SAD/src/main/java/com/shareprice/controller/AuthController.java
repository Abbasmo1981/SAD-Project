package com.shareprice.controller;

import com.shareprice.web.auth.AuthService;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    // Register endpoint
    public HttpHandler register() {
        return exchange -> {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendResponse(exchange, 405, "Method Not Allowed");
                return;
            }

            Map<String, String> form = parseForm(exchange);
            String username = form.get("username");
            String password = form.get("password");

            if (username == null || password == null) {
                sendResponse(exchange, 400, "Missing username or password");
                return;
            }

            boolean success = authService.register(username, password);

            if (success) {
                sendResponse(exchange, 200, "User registered successfully");
            } else {
                sendResponse(exchange, 409, "User already exists");
            }
        };
    }

    // Login endpoint
    public HttpHandler login() {
        return exchange -> {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendResponse(exchange, 405, "Method Not Allowed");
                return;
            }

            Map<String, String> form = parseForm(exchange);
            String username = form.get("username");
            String password = form.get("password");

            if (username == null || password == null) {
                sendResponse(exchange, 400, "Missing username or password");
                return;
            }

            String token = authService.login(username, password);

            if (token != null) {
                sendResponse(exchange, 200, "TOKEN: " + token);
            } else {
                sendResponse(exchange, 401, "Invalid login credentials");
            }
        };
    }

    // Logout endpoint
    public HttpHandler logout() {
        return exchange -> {
            String authHeader = exchange.getRequestHeaders().getFirst("Authorization");
            if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                sendResponse(exchange, 401, "Missing or invalid token");
                return;
            }

            String token = authHeader.substring("Bearer ".length()).trim();
            authService.logout(token);

            sendResponse(exchange, 200, "Logged out successfully");
        };
    }

    private Map<String, String> parseForm(HttpExchange exchange) throws IOException {
        String body = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
        Map<String, String> map = new HashMap<>();

        if (body.isEmpty()) return map;

        String[] pairs = body.split("&");
        for (String pair : pairs) {
            String[] kv = pair.split("=", 2);
            if (kv.length == 2) {
                String key = URLDecoder.decode(kv[0], StandardCharsets.UTF_8);
                String value = URLDecoder.decode(kv[1], StandardCharsets.UTF_8);
                map.put(key, value);
            }
        }
        return map;
    }

    private void sendResponse(HttpExchange exchange, int status, String message) throws IOException {
        byte[] responseBytes = message.getBytes(StandardCharsets.UTF_8);

        exchange.getResponseHeaders().set("Content-Type", "text/plain; charset=utf-8");
        exchange.sendResponseHeaders(status, responseBytes.length);

        try (OutputStream output = exchange.getResponseBody()) {
            output.write(responseBytes);
        }
    }
}
