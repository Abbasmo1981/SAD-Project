package com.shareprice.controller;

import com.shareprice.web.auth.AuthService;
import com.shareprice.web.domain.PriceData;
import com.shareprice.web.service.ISharePriceService;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.List;

public class PriceController {

    private final ISharePriceService service;
    private final AuthService auth;

    public PriceController(ISharePriceService service,
                           AuthService auth) {
        this.service = service;
        this.auth = auth;
    }

    public HttpHandler prices() {
        return exchange -> {
            try {
                String authHeader = exchange.getRequestHeaders().getFirst("Authorization");
                if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                    String error = "Missing or invalid Authorization header";
                    exchange.sendResponseHeaders(401, error.length());
                    exchange.getResponseBody().write(error.getBytes());
                    exchange.close();
                    return;
                }

                String token = authHeader.substring("Bearer ".length()).trim();
                if (!auth.validate(token)) {
                    String error = "Invalid or expired token";
                    exchange.sendResponseHeaders(401, error.length());
                    exchange.getResponseBody().write(error.getBytes());
                    exchange.close();
                    return;
                }

                String query = exchange.getRequestURI().getQuery();
                if (query == null || !query.contains("symbol=")) {
                    String error = "Missing stock symbol";
                    exchange.sendResponseHeaders(400, error.length());
                    exchange.getResponseBody().write(error.getBytes());
                    exchange.close();
                    return;
                }

                String symbol = query.split("symbol=")[1].split("&")[0];

                String endDate = LocalDate.now().toString();
                String startDate = LocalDate.now().minusDays(30).toString();

                List<PriceData> prices = service.getPrices(symbol, startDate, endDate);

                JSONArray arr = new JSONArray();
                for (PriceData p : prices) {
                    JSONObject o = new JSONObject();
                    o.put("date", p.getDate().toString());
                    o.put("open", p.getOpen());
                    o.put("high", p.getHigh());
                    o.put("low", p.getLow());
                    o.put("close", p.getClose());
                    arr.put(o);
                }

                JSONObject root = new JSONObject();
                root.put("symbol", symbol);
                root.put("prices", arr);

                byte[] bytes = root.toString().getBytes(StandardCharsets.UTF_8);

                exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
                exchange.sendResponseHeaders(200, bytes.length);
                exchange.getResponseBody().write(bytes);
                exchange.close();

            } catch (Exception e) {
                e.printStackTrace();
                String error = "Failed to load prices";
                exchange.sendResponseHeaders(500, error.length());
                exchange.getResponseBody().write(error.getBytes());
                exchange.close();
            }
        };
    }
}
